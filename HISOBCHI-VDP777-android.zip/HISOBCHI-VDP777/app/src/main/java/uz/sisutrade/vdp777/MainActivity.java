package uz.sisutrade.vdp777;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Base64;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import java.io.ByteArrayOutputStream;
import android.content.Intent;
import android.database.Cursor;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private WebView web;
    private WebView printWebView;
    private ValueCallback<Uri[]> chooser;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private Uri camUri;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF0A2670);
        tts = new TextToSpeech(this, status -> ttsReady = (status == TextToSpeech.SUCCESS));
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                camUri = null;
                try {
                    Intent chosen = p.createIntent();
                    boolean img = false;
                    for (String t : p.getAcceptTypes()) if (t != null && t.startsWith("image")) img = true;
                    if (img) {
                        java.io.File f = java.io.File.createTempFile("photo", ".jpg", getCacheDir());
                        camUri = androidx.core.content.FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fp", f);
                        Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        cam.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
                        cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        Intent ch = Intent.createChooser(chosen, "HISOBCHI VDP777");
                        ch.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
                        chosen = ch;
                    }
                    startActivityForResult(chosen, 1);
                } catch (Exception e) { chooser = null; camUri = null; return false; }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidApp");
        web.loadUrl("https://" + HOST + "/assets/index.html");
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq == 1 && chooser != null) {
            Uri[] res = WebChromeClient.FileChooserParams.parseResult(rs, d);
            if (res == null && rs == RESULT_OK && camUri != null) res = new Uri[]{camUri};
            chooser.onReceiveValue(res);
            chooser = null;
            camUri = null;
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){if(typeof S!='undefined'&&typeof closePick=='function'){var p=document.getElementById('pk');if(p&&p.style.display=='block'){closePick();return 1}}if(typeof S!='undefined'&&S.v){S.v=null;render();return 1}if(typeof S!='undefined'&&S.sec){go();return 1}return 0})()",
                r -> { if (!"1".equals(r)) finish(); });
    }

    @Override
    protected void onPause() {
        super.onPause();
        js("try{autoFlush()}catch(e){}");
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    private void js(final String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    private class Bridge {
        @JavascriptInterface
        public void save(String name, String data) {
            try {
                String low = name.toLowerCase();
                String mime = low.endsWith(".csv") ? "text/csv" : low.endsWith(".json") ? "application/json" : low.endsWith(".html") ? "text/html" : "text/plain";
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                try (OutputStream o = getContentResolver().openOutputStream(u)) {
                    o.write(data.getBytes("UTF-8"));
                }
            } catch (Exception e) { }
        }

        @JavascriptInterface
        public void saveB64(String name, String b64, String mime) {
            try {
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                try (OutputStream o = getContentResolver().openOutputStream(u)) {
                    o.write(bytes);
                }
            } catch (Exception e) { }
        }

        @JavascriptInterface
        public boolean shareFile(String name, String b64, String mime, String pkg) {
            try {
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                java.io.File f = new java.io.File(getCacheDir(), name);
                try (java.io.FileOutputStream fo = new java.io.FileOutputStream(f)) {
                    fo.write(bytes);
                }
                Uri u = androidx.core.content.FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fp", f);
                Intent it = new Intent(Intent.ACTION_SEND);
                it.setType(mime);
                it.putExtra(Intent.EXTRA_STREAM, u);
                it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if (pkg != null && pkg.length() > 0) it.setPackage(pkg);
                MainActivity.this.startActivity(it);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean hasAllFilesAccess() {
            return android.os.Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager();
        }

        @JavascriptInterface
        public void requestAllFilesAccess() {
            if (android.os.Build.VERSION.SDK_INT < 30) return;
            try {
                Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                try {
                    startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Exception e2) { }
            }
        }

        @JavascriptInterface
        public String autoSave(String data) {
            final String name = "sklad-avtokopiya.json";
            if (android.os.Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) {
                try {
                    java.io.File dir = new java.io.File(Environment.getExternalStorageDirectory(), "HISOBCHI VDP777");
                    if (!dir.exists()) dir.mkdirs();
                    java.io.File out = new java.io.File(dir, name);
                    try (java.io.FileOutputStream o = new java.io.FileOutputStream(out)) {
                        o.write(data.getBytes("UTF-8"));
                    }
                    return "ok";
                } catch (Exception e) {
                    return String.valueOf(e.getMessage());
                }
            }
            try {
                ContentResolver cr = getContentResolver();
                Uri coll = MediaStore.Files.getContentUri("external");
                Uri target = null;
                try (Cursor c = cr.query(coll, new String[]{MediaStore.MediaColumns._ID},
                        MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                        new String[]{name, "Documents/HISOBCHI/"}, null)) {
                    if (c != null && c.moveToFirst()) target = ContentUris.withAppendedId(coll, c.getLong(0));
                }
                if (target == null) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Documents/HISOBCHI");
                    target = cr.insert(coll, v);
                }
                if (target == null) return "нет доступа к памяти";
                try (OutputStream o = cr.openOutputStream(target, "wt")) {
                    o.write(data.getBytes("UTF-8"));
                }
                return "ok (Документы/HISOBCHI, не разрешён полный доступ к памяти)";
            } catch (Exception e) {
                return String.valueOf(e.getMessage());
            }
        }

        @JavascriptInterface
        public void scanBarcode() {
            runOnUiThread(() -> {
                try {
                    GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder().build();
                    GmsBarcodeScanning.getClient(MainActivity.this, options)
                        .startScan()
                        .addOnSuccessListener(barcode -> {
                            String v = barcode.getRawValue();
                            js("try{onBarcodeResult(" + jsStr(v) + ")}catch(e){}");
                        })
                        .addOnCanceledListener(() -> js("try{onBarcodeResult(null)}catch(e){}"))
                        .addOnFailureListener(e -> js("try{onBarcodeResult(null)}catch(e){}"));
                } catch (Exception e) {
                    js("try{onBarcodeResult(null)}catch(e){}");
                }
            });
        }

        @JavascriptInterface
        public String makeBarcodePng(String text, int w, int h) {
            try {
                if (text == null || text.trim().length() == 0) return "";
                BitMatrix m = new MultiFormatWriter().encode(text.trim(), BarcodeFormat.CODE_128, w, h);
                Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565);
                for (int x = 0; x < w; x++) {
                    for (int y = 0; y < h; y++) {
                        bmp.setPixel(x, y, m.get(x, y) ? Color.BLACK : Color.WHITE);
                    }
                }
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.PNG, 100, bos);
                return "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            } catch (WriterException e) {
                return "";
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void printHtml(String html, String title) {
            runOnUiThread(() -> {
                WebView pw = new WebView(MainActivity.this);
                printWebView = pw;
                pw.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        if (pm == null) return;
                        PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(title == null || title.length() == 0 ? "HISOBCHI" : title);
                        pm.print(title == null || title.length() == 0 ? "HISOBCHI" : title, adapter, new PrintAttributes.Builder().build());
                    }
                });
                pw.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            });
        }

        private String jsStr(String v) {
            if (v == null) return "null";
            String r = v.replace("\\", "\\\\");
            r = r.replace("\"", "\\\"");
            r = r.replace("\n", "\\n");
            r = r.replace("\r", "");
            return "\"" + r + "\"";
        }

        @JavascriptInterface
        public void speak(final String text, final String lang, final double pitch) {
            runOnUiThread(() -> {
                try {
                    if (!ttsReady) return;
                    Locale loc = Locale.forLanguageTag(lang);
                    int r = tts.setLanguage(loc);
                    if (r < 0 && lang.startsWith("uz")) r = tts.setLanguage(Locale.forLanguageTag("tr-TR"));
                    try {
                        for (android.speech.tts.Voice vv : tts.getVoices()) {
                            String n = vv.getName().toLowerCase();
                            if (vv.getLocale().getLanguage().equals(loc.getLanguage()) && n.contains("male") && !n.contains("female")) {
                                tts.setVoice(vv);
                                break;
                            }
                        }
                    } catch (Exception e2) { }
                    tts.setPitch((float) pitch);
                    tts.setSpeechRate(1.25f);
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "vdp777");
                } catch (Exception e) { }
            });
        }

        @JavascriptInterface
        public boolean canBio() {
            try {
                BiometricManager m = (BiometricManager) getSystemService(Context.BIOMETRIC_SERVICE);
                if (Build.VERSION.SDK_INT >= 30)
                    return m.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS;
                return m.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public void bio(final String title, final String cancel) {
            runOnUiThread(() -> {
                try {
                    BiometricPrompt.Builder bb = new BiometricPrompt.Builder(MainActivity.this)
                            .setTitle(title)
                            .setNegativeButton(cancel, getMainExecutor(), (d, w) -> js("bioResult(false)"));
                    if (Build.VERSION.SDK_INT >= 30)
                        bb.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK);
                    bb.build().authenticate(new CancellationSignal(), getMainExecutor(),
                            new BiometricPrompt.AuthenticationCallback() {
                                @Override
                                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                                    js("bioResult(true)");
                                }
                                @Override
                                public void onAuthenticationError(int code, CharSequence msg) {
                                    js("bioResult(false)");
                                }
                            });
                } catch (Exception e) { js("bioResult(false)"); }
            });
        }
    }
}
